<?php
    header('location: ../deconnexion.php');
?>